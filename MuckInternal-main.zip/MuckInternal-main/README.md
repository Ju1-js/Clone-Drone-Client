# MuckInternal
<img src="https://i.imgur.com/FekWj01.png"/>
Internal cheat for Muck

# Features
God mode, infinite stamina, infinite food, spawn any item, spawn any powerup

Instant destroy all trees, all rocks, all resources, all chests, kill all mobs, instant activate all shrines

# Injection tutorial

Clone repo and open .sln file in Visual Studio

Compile in 'Release / Any CPU'

Download SharpMonoInjector (https://github.com/warbler/SharpMonoInjector)

Open SharpMonoInjector and open Muck

Select game and DLL file

Namespace is MuckInternal, class name is Loader, method name is Init

Press inject

# Credits
Zat - https://www.unknowncheats.me/forum/unity/285864-beginners-guide-hacking-unity-games.html

Aragon12 - https://www.unknowncheats.me/forum/unity/437277-mono-internal-optimisation-tips.html

https://github.com/yapht - Answering some of my C# questions
